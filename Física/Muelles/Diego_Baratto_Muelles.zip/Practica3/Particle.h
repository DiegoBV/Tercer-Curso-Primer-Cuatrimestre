#pragma once
#include "RenderUtils.hpp"

class ParticleForceRegistry;

class Particle
{
private:
	
	RenderItem* renderItem = nullptr;                  //Render Item

	float damping;                                     //fuerza de rozamiento

	float inverse_mass;                                //masa inversa

	bool active = false;                                //active	

	float lifeTime_;                                   //lifetime

	physx::PxTransform transform;                      //transform

	Vector3 p;                                        //Posicion en el mundo

	Vector3 v;                                        //Velocidad (lineal) en el mundo

	Vector3 a;                                        //Aceleracion (lineal) en el mundo

	Vector3 force;                                    // Accumulated force	

	void integrate(float t);                         //Integracion

	void clearForce();                               // Clears accumulated force


public:

	static ParticleForceRegistry registry_;                     //variable estatica del registro de Particles --> todos tienen acceso al mismo

	
	enum Shape { Capsule, Sphere, Box };                       //enum tipos de shapes

	
	struct Medidas {                                          //struct medidas del shape
		float x_;

		float y_;

		union{
			float z_; //si no se necesitan no ocupan memoria
		};

		//constructores
		Medidas(float x) : x_(x) {};
		Medidas(float x, float y) : x_(x), y_(y) {};
		Medidas(float x, float y, float z) : x_(x), y_(y), z_(z) {};
	};


	Particle(RenderItem* rItem, float inverse_mass = 1.0) : renderItem(rItem), inverse_mass(inverse_mass), 
		damping(0.95), v(0, 0, 0), a(0, 0, 0), p(0, 0, 0), transform(p), lifeTime_(0), force(0, 0, 0) { renderItem->transform = &transform; };

	Particle() : renderItem(nullptr), inverse_mass(1), damping(0.95), lifeTime_(0) {};

	virtual ~Particle() { if (renderItem != nullptr) delete renderItem; };

	virtual void update(float time) { integrate(time); lifeTime_ += time; };

	//-------------------------------------------------------------------GETS------------------------------------------------------------

	//get mass
	inline int getMass() const { return 1/inverse_mass; };

	//get dumping
	inline float getDamping() const { return damping; };

	//getPosition
	inline Vector3 getPosition() const { return p; }

	//getAcceleration
	inline Vector3 getAcceleration() const { return a; }

	//getVelocity
	inline Vector3 getVelocity() const { return v; }

	//distancia recorrida desde el inicio
	inline const unsigned int getDistanceTraveled() { return p.magnitude(); };

	//isactive
	inline const bool isActive() { return active; };

	//tiempo de vida
	inline const float getLifeTime() { return lifeTime_; };

	//-------------------------------------------------------------------SETS--------------------------------------------------------------

	//setRotation
	//inline void setRotation(const Vector3 rot) { renderItem->transform->q.rotate(rot); };

	//setPosition
	inline void setPosition(const Vector3 pos) { p = pos; transform.p = p; };

	//setAcc
	inline void setAcceleration(const Vector3 a_) { a = a_; };

	//setVelocity
	inline void setVelocity(const Vector3 v_) { v = v_; };

	//set renderItem
	inline void setRenderItem(RenderItem* rn) { renderItem = rn; };

	//setDamping
	inline void setDamping(const float newDamping) { if (newDamping >= 0 && newDamping <= 1) damping = newDamping; } //else ---> avisar, lanzar una excepcion...?

	//set inerse_mass
	inline void setMass(const float newMass) { inverse_mass = newMass; };

	//set shape si no tiene forma
	inline void setShape(Shape shp, Medidas size) { renderItem->shape = createShape(shp, size);};

	//setSphereShape
	inline void setSphereShape(float r) { renderItem->shape = createShape(Sphere, r); };

	//setCapsuleShape
	inline void setCapsuleShape(float r, float R) { renderItem->shape = createShape(Capsule, { r, R }); };

	//setBoxShape
	inline void setBoxShape(float x, float y, float z) { renderItem->shape = createShape(Box, Medidas( x, y, z) ); };

	//set color
	inline void setColor(Vector4 color_) { renderItem->color = color_; };

	//setActive and RegisterRenderItem
	inline void setActive() { active = true;  RegisterRenderItem(renderItem); resetLifeTime(); };

	//setInactive and DeregisterRenderItem
	inline void setInactive() { if (active) { active = false;  resetLifeTime();  DeregisterRenderItem(renderItem); } };

	//set JUST THE BOOL ACTIVE 
	inline void setActive(bool nAct) { active = nAct; };

	//------------------------------------------------------------------------------OTHERS-------------------------------------------------

	// Add force to apply in next integration only
	void addForce(const Vector3& f);

	//reset tiempo de vida
	inline void resetLifeTime() { lifeTime_ = 0; };

protected:
	//crea la shape dependiendo del tipo y las medidas introducidas
	physx::PxShape* createShape(Shape tipo, Medidas size);
};

